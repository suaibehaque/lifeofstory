<?php

include_once('connect.php');


if(isset($_REQUEST["SignUpBtn"]))
{
    $fname = $_REQUEST["fname"];
    $lname = $_REQUEST["lname"];
    $usr_email = $_REQUEST["usr_email"];
    $unenc_usr_pwd = $_REQUEST["usr_pwd"];
    $usr_pwd = md5(sha1($unenc_usr_pwd));
    $auth_code = md5(sha1($usr_email.$usr_pwd));
    $day = $_REQUEST["day"];
    $month = $_REQUEST["month"];
    $year = $_REQUEST["year"];
    $date_birth = $day."-".$month."-".$year;
    $usr_gen = $_REQUEST["gender"];
   
}


?>