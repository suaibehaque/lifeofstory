<!doctype html>
<html lang="en-US">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Life-Of-Story</title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link rel="stylesheet" href="privacy&policy.css"/>
</head>
<body>
<header>
<div class="title_of_site">

LIFE-OF-STORY

</div>


<nav class="navbar navbar-expand-md navbar-dark bg-dark naver_design">
      
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link home_menu " href="../index.html">Home/হোম<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link home_menu story" href="../story/acharon/story_acharon.html">Story/গল্প  <span class="sr-only">(current)</span></a>
          </li>
		  <li class="nav-item active">
            <a class="nav-link home_menu poem" href="../poem/Morning Of Love/poem_Morning Of Love.html">Poem/কবিতা<span class="sr-only">(current)</span></a>
          </li>
		  <li class="nav-item active">
            <a class="nav-link home_menu jokes" href="../jokes/boltur jokes/boltur jokes 1.html">Jokes/কৌতুক
			<span class="sr-only">(current)</span></a>
          </li>
		  <li class="nav-item active">
            <a class="nav-link home_menu puzzle" href="../puzzle/1st part puzzle/1st part puzzle.html">Puzzle/ধাঁধা<span class="sr-only">(current)</span></a>
          </li>
		  <li class="nav-item active">
            <a class="nav-link home_menu rhythm" href="../rhythm/1st part rhythm/1st part rhythm.html">Rhythm/ছন্দ<span class="sr-only">(current)</span></a>
          </li>
		 
        </ul>
        
      </div>
    </nav>



</header>
<div class="container-fluid">
<div class="row full_color">

<div class="col-md-12">
<h1>Privacy policy: </h1>

The following statements describe the privacy practices for LIFE-OF-STORY:
<ul>
<li>We do not collect any personal information from our users</li>
<li>Visits are logged for aggregate statistics and diagnosis</li>
<li>Security settings protect the misuse of sensitive information</li>
</ul>


</div>
</div>
</div>


<footer>
    <div class="container-fluid">
<div class="row ">

<div class="col-md-4 ">

<div class="footer_title footer_title_design"><span>Life-Of-Story</span></div>

</div>

<div class="col-md-4">
			
			<ul class="footer_ul">
			<div class="footer_menu_title">Menu</div>
			<li><a class="footer_home_menu story" href="../story/Accident/story_Accident.html">Story/গল্প</a></li>
			<li><a class=" footer_home_menu poem" href="../poem/shikhok/poem_shikhok.html">Poem/কবিতা</a></li>
			<li><a class=" footer_home_menu jokes" href="../jokes/boltur jokes/boltur jokes 1.html" >Jokes/কৌতুক</a></li>
			<li><a class=" footer_home_menu puzzle" href="../puzzle/1st part puzzle/1st part puzzle.html">Puzzle/ধাঁধা</a></li>
			<li><a class=" footer_home_menu rhythm" href="../rhythm/1st part rhythm/1st part rhythm.html">Rhythm/ছন্দ</a></li>
			</ul>

</div>

<div class="col-md-4">
			<ul>
			<div class="footer_menu_contact_title">Contact Us</div>
			<div class="contact_section">
				G-Mail: <a target="_blank" href="https://mail.google.com">lifeofstory3@gmail.com<a><br/>
				Facbook: <a target="_blank" href="https://www.facebook.com/lifeofstorys">Life-Of-Story</a>
				
				
				
			</div>
			</ul>
</div>

<div style="margin-left:20px;">
<ul>
This site for entertainment all of the users. While using this site, you agree to have read and accepted our <a href="../tearms/tearm and condition.php">terms & conditions</a> and <a href="../privacy/privacy&policy.php"> privacy policy </a>.</ul>

</div>
</div>
</div>
</footer>
<script src="javascript/home design.js" type="text/javascript"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>