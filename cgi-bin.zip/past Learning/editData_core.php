<?php

require_once("connect.php");

if(isset($_REQUEST["update"])){
    
    $id = $_REQUEST["id"];
    $fname = $_REQUEST["fname"];
    $lname = $_REQUEST["lname"];
    $email_addr = $_REQUEST["email_addr"];
    $usr_pwd = $_REQUEST["usr_pwd"];
    
   $setQuery = "UPDATE my_info SET fname='$fname',lname='$lname',email_addr='$email_addr',usr_pwd='$usr_pwd' WHERE id= $id";
    $runQuery = mysqli_query($connect,$setQuery);
    if($runQuery == true)
    {
        header("location: index.php?dataedited");
    }
    
}

?>