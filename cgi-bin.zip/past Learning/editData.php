<!doctype html>
<html>
    <head>
        <title>LifeOfStory</title>
        </head>
    <body>
        
        <?php 
            
            require_once("connect.php");
            
            if(isset($_REQUEST["edit_id"]))
            {
                
              $editId = $_REQUEST["edit_id"];
              $fname = $_REQUEST["fname"];
              $lname = $_REQUEST["lname"];
              $email_addr = $_REQUEST["email_addr"];
              $usr_pwd = $_REQUEST["usr_pwd"];
            
              $selectQuery = "SELECT * FROM my_info WHERE id=$editId;";
              $runQuery = mysqli_query($connect,$selectQuery);
              if($getId = mysqli_fetch_array($runQuery)){
                  
               
            ?>
            
            <form method="POST" action="editData_core.php">
                
            <input type="text" placeholder="First Name" value="<?php echo $getId["fname"]; ?>" name="fname"/>
            <input type="text" placeholder="Last Name" value="<?php echo $getId["lname"]; ?>" name="lname"/>
            <input type="email" placeholder="Type Email" value="<?php echo $getId["email_addr"]; ?>" name="email_addr"/>
            <input type="text" placeholder="Type Password" value="<?php echo $getId["usr_pwd"]; ?>" name="usr_pwd"/>
            <input type="hidden" value="<?php echo $getId["id"]; ?>" name="id" />
            <input type="submit" value="Edit Form" name="update"/>
            
            </form>
            
            <?php }}?>
            
            </body>
</html>