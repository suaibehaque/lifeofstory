<!doctype html>
<html>
    <head>
        <title>LifeOfStory</title>
        </head>
    <body>
        <form method="POST">
            
            <input type="text" placeholder="search" name="searchTearm"/>
            <input type="submit" value="search" />
            
            
            </form>
            <br/>
            <br/>
            <?php 
            
                if(isset($_REQUEST["searchTearm"]))
                {
                    $searchTearm = $_REQUEST["searchTearm"]; ?>
               
            <?php
            
            if(isset($_REQUEST["deleted"]))
            {
                echo "Data Has Been Deleted.";
            }elseif(isset($_REQUEST["dataedited"]))
            {
                echo "Data has been edited.";
            }
            
            ?>
            
            <table border="1px" style="text-align:center;">
            
            <tr>
            
            <th>S.N</th>
            <th>DB ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email Address</th>
            <th>Password</th>
            <th>Avatar</th>
            <th>Action</th>
            
            
            </tr>
            
            <?php
             require_once("connect.php");
             
             $selectQuery = "SELECT * FROM my_info WHERE fname LIKE '%$searchTearm%'";
             $runQuery = mysqli_query($connect,$selectQuery);
             
             if($runQuery==true){
             $srialCount = 1;
                 while($mydata = mysqli_fetch_array($runQuery)){ ?>
             
                   <tr>
                   
                    <td><?php echo $srialCount; ++$srialCount; ?></td>
                    <td><?php echo $mydata["id"]; ?></td>
                    <td><?php echo $mydata["fname"]; ?></td>
                    <td><?php echo $mydata["lname"]; ?></td>
                    <td><?php echo $mydata["email_addr"]; ?></td>
                    <td><?php echo $mydata["usr_pwd"]; ?></td>
                    <td><img width="100px" src="images/<?php echo $mydata["avatar"]; ?>" alt="profile_pic"/></td>
                    <td> <a href="editData.php?edit_id=<?php echo $mydata["id"] ?>"> Edit </a> | <a onclick="return confirm('Are You Sure To Delete This Data?')" href="deleteData_core.php?id=<?php echo $mydata["id"];?>"> Delete </a></td>
                   
                   </tr>
                   
            <?php }} ?>
            
            </table>
            <?php  }?>
    </body>
</html>