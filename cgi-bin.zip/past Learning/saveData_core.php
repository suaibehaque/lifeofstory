<?php

require_once("connect.php");

if(isset($_REQUEST["fname"]) && isset($_REQUEST["lname"]) && isset($_REQUEST["email_addr"]) && isset($_REQUEST["usr_pwd"]))
{
    $fname = $_REQUEST["fname"];
    $lname = $_REQUEST["lname"];
    $email_addr = $_REQUEST["email_addr"];
    $usr_pwd = $_REQUEST["usr_pwd"];
    
    $filename = $_FILES["upFile"]["name"];
    $tmpfilename = $_FILES["upFile"]["tmp_name"];
    $location = "images";
    $nameForDataBase = uniqid().".jpg"; 
    
    move_uploaded_file($tmpfilename,"$location/$nameForDataBase");

    $insertQuery = "INSERT INTO my_info (fname,lname,email_addr,usr_pwd,avatar) VALUES ('$fname','$lname','$email_addr','$usr_pwd','$nameForDataBase')";
    $runQuery = mysqli_query($connect,$insertQuery);
    
    if($runQuery==true){
        
        header("location: index.php?action=true");
        
    }else{
        
        header("location: index.php?action=false");
        
    }
    
}


?>