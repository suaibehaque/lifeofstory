<?php


$db_usrname = "Nasim";
$db_pwd = "12345";

$username = $_REQUEST["user_name_ajax"];
$password = $_REQUEST["user_pwd_ajax"];

if($db_usrname==$username && $db_pwd==$password)
{
    echo "Loged In";
    
}else{
    
    echo "Password or Username is Wrong!";
}


?>