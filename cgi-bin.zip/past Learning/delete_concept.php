<!doctype html>
<html>
    <head>
        <title>LifeOfStory</title>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        </head>
    <body>
        <?php
        
            if(isset($_REQUEST["action"])){
                
                if($_REQUEST["action"]=="true"){
                    
                    echo "<h3 style='color:green'> Data Inserted</h3>";
                    
                }else{
                    
                    echo "<h3 style='color:red'> Data Not Inserted</h3>";
                    
                }
                
            }
        
        ?>
        <form method="POST" enctype= "multipart/form-data" action="saveData_core.php">
            
            <input type="text" placeholder="First Name" name="fname"/>
            <input type="text" placeholder="Last Name" name="lname"/>
            <input type="email" placeholder="Type Email" name="email_addr"/>
            <input type="password" placeholder="Type Password" name="usr_pwd"/>
            <input type="file" name="upFile"/>
            <input type="submit" value="Save Form"/>
            
            
            </form>
           
            <div style="margin-bottom:50px;margin-top:50px">
            <div id="div_for_spiner" style="float:left;width:100px" ></div>
            <div id="showComment" style="color:red;float:right;width:100px">
                <h3></h3>
                </div>
                </div>
            <?php
            
            if(isset($_REQUEST["deleted"]))
            {
                echo "Data Has Been Deleted.";
            }elseif(isset($_REQUEST["dataedited"]))
            {
                echo "Data has been edited.";
            }
            
            ?>
            
            <table border="1px" style="text-align:center;">
            
            <tr>
            
            <th>S.N</th>
            <th>DB ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email Address</th>
            <th>Password</th>
            <th>Avatar</th>
            <th>Action</th>
            
            
            </tr>
            
            <?php
             require_once("connect.php");
             
             $selectQuery = "SELECT * FROM my_info";
             $runQuery = mysqli_query($connect,$selectQuery);
             
             if($runQuery==true){
             $srialCount = 1;
                 while($mydata = mysqli_fetch_array($runQuery)){ ?>
             
                   <tr>
                   
                    <td><?php echo $srialCount; ++$srialCount; ?></td>
                    <td><?php echo $mydata["id"]; ?></td>
                    <td><?php echo $mydata["fname"]; ?></td>
                    <td><?php echo $mydata["lname"]; ?></td>
                    <td><?php echo $mydata["email_addr"]; ?></td>
                    <td><?php echo $mydata["usr_pwd"]; ?></td>
                    <td><img width="100px" src="images/<?php echo $mydata["avatar"]; ?>" alt="profile_pic"/></td>
                    <td> <a href="editData.php?edit_id=<?php echo $mydata["id"] ?>"> Edit </a> |
                    <a onclick="return confirm('Are You Sure To Delete This Data?')" 
                     data-amarvalue="<?php echo $mydata["id"]; ?>" id="hrefData" href="#"> 
                    Delete </a></td>
                   
                   </tr>
                   
            <?php }} ?>
            
            </table>
            <script type="text/javascript">
            
            $(document).ready(function(){
                
                
                $("a#hrefData").on("click",function(){
                    
                    var myValue = $(this).data("amarvalue");
                    
                    $.post("deleteData_core.php",{id:myValue},function(getIdFrom_deleteData_core)
                    {
                        
                        if(getIdFrom_deleteData_core=="1"){
                            
                            $("#div_for_spiner").html("<img width='50px' src='spinner.gif'/>");
                            setTimeout(function(){
                                
                                 $("div#showComment h3").html("Data Deleted!");
                                 $("#div_for_spiner img").remove();
                                 
                                                                    
                            },2000);
                           
                           
                            
                        }
                         
                        
                    });
                    
                    
                    
                   $(this).parent().parent().remove();
                    
                    setTimeout(function(){
                                     
                                      $("div#showComment h3").remove();
                                     
                                 },3000);
                });
                
                
               
                
            });
            
            </script>
    </body>
</html>