<?php

require_once("connect.php");
    
    $getId = $_REQUEST["id"];
    
    $deleteQuery = "DELETE FROM my_info WHERE id=$getId";
    $runQuery = mysqli_query($connect,$deleteQuery);
    
    if($runQuery==true)
    {
        echo "1";
    }

?>