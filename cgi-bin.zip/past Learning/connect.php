<?php

            $host = "localhost";
            $dbUser = "lifeofst_mdsuaibe";
            $dbPwd = "mdsuaibe19211925";
            $dbname= "lifeofst_mydatabase";
            $connect = mysqli_connect($host, $dbUser, $dbPwd, $dbname);
            if($connect==false)
            {
                echo "Couldn't Connect to Database".mysqli_connect_error();
            }

?>