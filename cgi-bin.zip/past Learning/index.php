<!doctype html>
<html>
    <head>
        <title>LifeOfStory</title>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </head>
    <body>
       
    <from onsubmit="return false" method="POST">
    
        <input value="Nasim" type="text" name="usrname" id="usrname"/>
        <input type="text" name="pwd" id="pwd" />
        <input type="submit" value="Login" name="submitButton" id="submitButtonId"/>
        <input style="border:none; color:green; font_weight:bold;text-transform:uppercase;" type="readonly" id="readonlyId"/>
    </from>
       
       <div id="spinner">
          
       </div>
       
<script type="text/javascript">


    
$(document).ready(function(){
    
    $("input#submitButtonId").on("click",
function(){
    
$("div#spinner").html('<img src="spinner.gif" alt="loadingPic"/>');
setTimeout(function(){
    
     var user_Name = $("input#usrname").val();
    var user_Pwd = $("input#pwd").val();
    
    $.post("login_verification_ajax_core.php",{user_name_ajax:user_Name,user_pwd_ajax:user_Pwd},
    function(mydata){
        
$("#readonlyId").val("hello");
$("div#spinner img").remove();
    });
    
},2000)



    
    
});
    
    
});
    
</script>
       
       
    </body>
</html>