<?php require_once("header.php");
require_once("connect.php");
?>
<div class="container-fluid">
<div class="row full_color">

<div class="col-md-8">

<div class="container-fluid">
<div class="row full_color">
<div class="col-md-3"></div>
<div class="col-md-6">
<div class="signUp_border">
<div class="form_signUp_title"><span>Sign Up</span></div>
<div class="form_signUp">

<form method="POST" action="core file/login_core.php">
    <input type="email" class="signup_input_feild" placeholder="Type Your Email Address" name="usr_email"/><br/>
    <input type="password" class="signup_input_feild" placeholder="Type Your Password" name="usr_pwd"/> 
    <input type="submit" value="Sign Up" class="signUpBtn" name="SignUpBtn"/>
    
</form>
</div>
</div>

</div>
<div class="col-md-3"></div>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- disply -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8559304347963965"
     data-ad-slot="4204462024"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
</div>



</div>




<?php

require_once("side content.php");

?>


</div>
</div>

<?php require_once("footer.php")?>