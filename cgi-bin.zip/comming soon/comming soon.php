<?php

require_once("../header.php");

?>

<div class="container-fluid">
<div class="row full_color">



<div class="col-md-8 acharon">

<div>

<h1>Coming soon.....</h1>

</div>

</div>



 



<?php

require_once("../side content.php");

?>


</div>
</div>


<?php 

require_once("../footer.php");

?>