<?php require_once("header.php");?>
<br/>
<form action="changepwd_core.php" method="POST">
    <input type="text" placeholder="Old Password" name="old_pwd"/>
    <input type="text" placeholder="New Password" name="new_pwd"/>
    <input type="text" placeholder="Confrim Password" name="confrim_pwd"/>
    <input type="submit" value="Change Password" name="signUpButton"/>
</form>
<?php

if(isset($_REQUEST["error"]))
{
    echo "<b style='color:green'>".$_REQUEST["error"]."</b>";
   
}

?>

<?php require_once("footer.php");?>