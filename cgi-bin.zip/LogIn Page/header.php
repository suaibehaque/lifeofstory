<?php

session_start();

require_once("config.php");

/*if(isset($_COOKIE["currentUser"])){
    
    $currentAuth = $_COOKIE["currentUser"];
    
    $findhisCookie = "SELECT * FROM my_info WHERE auth='$currentAuth'";
    $runcookie = mysqli_query($connect,$findhisCookie);
    
    if($runcookie==true)
    {
        if(mysqli_num_rows($runcookie)==0)
        {
                setcookie("currentUser","",time()-(86400*10));
                header("location: login.php");

        }
    }
    
}*/

?>
<header>
<!doctype html>
<html lang="en-US">
    <head>
        <meta charset="UTF-8"/>
        <title>Welcome To Our Website</title>
        <link rel="stylesheet" href="indexStyle.css"/>
        </head>
        <body>
            <div id="wreaper">
<h1>Welcome To My Website</h1>
<a href="index.php">Home</a>
<?php
if(isset($_COOKIE["currentUser"]))
{
    echo "<a href='profile.php'>Profile</a>";
}
if(!isset($_COOKIE["currentUser"]))
{
    echo "<a href='login.php'>Login</a>";
}else{
    
    echo "<a href='logout_core.php'>Logout</a>";
    
}

?>
</header>