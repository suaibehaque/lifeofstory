                <?php 

if(!isset($_COOKIE["currentUser"]))
{
    header("location: index.php");
}?>

                <?php require_once("header.php"); ?>
                <div id="content">
                    <h1>
                        
                        <?php
                        
                        if(isset($_COOKIE["currentUser"]))
                        {
                            $currentUserEmail = $_COOKIE["currentUser"];
                            
                            $nameQuery = "SELECT * FROM my_info WHERE auth='$currentUserEmail'";
                            $runQuery = mysqli_query($connect,$nameQuery);
                            if($nameQuery==true)
                            {
                                while($getInfo = mysqli_fetch_array($runQuery))
                                {
                                    echo $getInfo["fname"]." ".$getInfo["lname"];
                                    echo "</h1>";
                                    $userPicFromDB = $getInfo["avatar"];
                                    echo "<img src='../past Learning/images/$userPicFromDB' width='200px' alt='profile pic'/>";
                                }
                            }
                        }
                        
                        ?>
                        
                    
                    <p>This is Nasim's Profile</p>
                    <a href="changepwd.php">Change Password</a>
                </div>
                <?php require_once("footer.php"); ?>
