<?php 
    require_once("config.php");
    
    $getCurrentUser = $_COOKIE["currentUser"];
    
    $old_pwd = $_REQUEST["old_pwd"];
    $new_pwd = $_REQUEST["new_pwd"];
    $confrim_pwd = $_REQUEST["confrim_pwd"];
    
    $checkoldpwd = "SELECT * FROM my_info WHERE auth='$getCurrentUser'";
    $runquery = mysqli_query($connect,$checkoldpwd);
    $countRow = mysqli_num_rows($runquery);
    
    
 if($runquery==true)
 {
  if($countRow===1)
  {
      
      while($getInfo = mysqli_fetch_array($runquery))
      {
          $userEmail = $getInfo["email_addr"];
      }
      
  }
 }
 $authTokenGenateate = md5(sha1($userEmail.$old_pwd));
 if($authTokenGenateate==$getCurrentUser && $new_pwd==$confrim_pwd)
 {
    
    $newEncPass = md5(sha1($confrim_pwd));
    $newEncAuth = md5(sha1($userEmail.$confrim_pwd));
        
    $updatePassword = "UPDATE my_info SET usr_pwd='$newEncPass',auth='$newEncAuth' WHERE auth='$getCurrentUser'";
    $runQueryForUpdate = mysqli_query($connect,$updatePassword);
    
    
    
    if($runQueryForUpdate==true)
    {
        
        setcookie("currentUser","",time()-(86400*10));//logout me first
       // setcookie("currentUser",$newEncAuth,time()+(86400*7));
      // header("location: changepwd.php?error=Password has been changed.");
        
        
            /*if(mysqli_num_rows($runQueryForUpdate)===1){
            echo "password has been changed";}
            */
        
    }
    
    
 }else{
     
     header("location: changepwd.php?error=Password did not match.");
     
 }
 
 
 
?>