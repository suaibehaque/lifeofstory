<?php

require_once("config.php");

$fname = $_REQUEST["fname"];
$lname = $_REQUEST["lname"];
$email_addr = $_REQUEST["email_addr"];
$usr_pwd = $_REQUEST["usr_pwd"];
$enc_usr_pwd = md5(sha1($usr_pwd));
$enc_auth_token = md5(sha1($email_addr.$usr_pwd));

$innsertQuery = "INSERT INTO my_info (fname,lname,email_addr,usr_pwd,auth) VALUES ('$fname','$lname','$email_addr','$enc_usr_pwd','$enc_auth_token')";
$runQuery = mysqli_query($connect,$innsertQuery);
if($runQuery==true)
{
    header("location: registration.php?signup_done=Registration Completed");
}

?>