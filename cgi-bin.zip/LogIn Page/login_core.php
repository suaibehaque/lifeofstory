<?php 
    require_once("config.php");

    $inputusrname = $_REQUEST["usrname"];
    $inputpwd = $_REQUEST["pwd"];
    $authToken = md5(sha1($inputusrname.$inputpwd));
    
    $matchQuery = "SELECT * FROM my_info WHERE auth='$authToken'";
    $runQuery = mysqli_query($connect ,$matchQuery);
    $rowCount = mysqli_num_rows($runQuery);
    
    if($runQuery==true)
    {
        if($rowCount===1){
       setcookie("currentUser",$authToken,time()+(86400*7));
       header("location: profile.php");
        
    
    }else{
        
        header("location: login.php?wrong_info");
        
    }
        
    }

?>