<?php 

if(isset($_COOKIE["currentUser"]))
{
    header("location: profile.php");
}

?>
                <?php require_once("header.php"); ?>
                <div id="content">
                    <div id="login_form">
                    <h1>Login Form</h1>
                    <form action="login_core.php" method="POST">
                        <input type="email" placeholder="Email" name="usrname"/><br/><br/>
                        <input type="password" placeholder="Password" name="pwd"/><br/><br/>
                        <input type="submit" value="Log In"/>
                        <?php 
                        
                        if(isset($_REQUEST["wrong_info"])){
                            
                            echo "<br/><br/><b style='color:red'>Username or Password is incorrect.</b>";
                            
                        }
                        
                        ?>
                    </form>
                    </div>
                </div>
                <?php require_once("footer.php"); ?>