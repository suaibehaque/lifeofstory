<?php require_once("header.php");?>
<br/>
<form action="registration_core.php" method="POST">
    <input type="text" placeholder="First Name" name="fname"/>
    <input type="text" placeholder="Last Name" name="lname"/>
    <input type="email" placeholder="Email Address" name="email_addr"/>
    <input type="password" placeholder="Password" name="usr_pwd"/>
    <input type="submit" value="Sign Up" name="signUpButton"/>
</form>
<?php

if(isset($_REQUEST["signup_done"]))
{
    echo "<b style='color:green'>".$_REQUEST["signup_done"]."</b>";
   
}

?>

<?php require_once("footer.php");?>