<?php

$ServerName = "localhost";
$DBUserName = "lifeofst_mdsuaibe";
$DBUserPassword = "mdsuaibe19211925";
$DBName = "lifeofst_mydatabase";

$connect = mysqli_connect($ServerName,$DBUserName,$DBUserPassword,$DBName);
if($connect==false)
{
    echo "Database could not be connected!".mysqli_error();
}
?>