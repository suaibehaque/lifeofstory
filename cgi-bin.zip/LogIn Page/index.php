                <?php require_once("header.php"); ?>
                <div id="content">
                    <h1>Our Services</h1>
                    <p>We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.
                    We are Web Designer.We are Web Designer.We are Web Designer.</p>
                </div>
                <?php require_once("footer.php"); ?>
            </div>
            </body>
    </html>