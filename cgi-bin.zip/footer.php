<footer>
    <div class="container-fluid">
<div class="row ">


<div style="width:100%;margin:auto;padding-top:20px;text-align:center;"><script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- under menu ad -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8559304347963965"
     data-ad-slot="7520964852"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script></div>


<div class="col-md-4 ">

<div class="footer_title footer_title_design"><span>Life-Of-Story</span></div>

</div>

<div class="col-md-4">
			
			<ul class="footer_ul">
			<div class="footer_menu_title">Menu</div>
			<li><a class="footer_home_menu story" href="#contents_of_story">Story/গল্প</a></li>
			<li><a class=" footer_home_menu poem" href="#contents_of_poem">Poem/কবিতা</a></li>
			<li><a class=" footer_home_menu jokes" href="#contents_of_jokes" >Jokes/কৌতুক</a></li>
			<li><a class=" footer_home_menu puzzle" href="#contents_of_puzzle">Puzzle/ধাঁধা</a></li>
			<li><a class=" footer_home_menu rhythm" href="#contents_of_rhythm">Rhythm/ছন্দ</a></li>
			<li><a class=" footer_home_menu quote" href="#contents_of_quote">Quote/উক্তি</a></li>
			</ul>

</div>

<div class="col-md-4">
			<ul>
			<div class="footer_menu_contact_title">Contact Us</div>
			<div class="contact_section">
				G-Mail: <a target="_blank" href="https://mail.google.com">lifeofstory3@gmail.com<a><br/>
				Facbook: <a target="_blank" href="https://www.facebook.com/lifeofstorys">Life-Of-Story</a>
				
				
				
			</div></ul>

</div>
<div style="margin-left:20px;">
<ul>
This site for entertainment all of the users. While using this site, you agree to have read and accepted our <a href="http://www.life-of-story.com/tearms/tearm and condition.php">terms & conditions</a> and <a href="http://www.life-of-story.com/privacy/privacy&policy.php"> privacy policy </a>.</ul>

</div>

</div>
</div>
</footer>

<script>
$(document).ready(function(){
 
 $( ".story" ).click(function() {
  $(".all_contents").css({"display": "none"}),
  $(".novel_menu").css({"display": "none"}),
  $(".poem_menu").css({"display": "none"}),
  $(".story_menu").css({"display": "block"}),
  $(".jokes_menu").css({"display": "none"}),
  $(".puzzle_menu").css({"display": "none"}),
  $(".quote_menu").css({"display": "none"}),
  $(".rhythm_menu").css({"display": "none"})
});
$( ".novel" ).click(function() {
  $(".all_contents").css({"display": "none"}),
  $(".novel_menu").css({"display": "block"}),
  $(".poem_menu").css({"display": "none"}),
  $(".story_menu").css({"display": "none"}),
  $(".jokes_menu").css({"display": "none"}),
  $(".puzzle_menu").css({"display": "none"}),
  $(".quote_menu").css({"display": "none"}),
  $(".rhythm_menu").css({"display": "none"})
});
$( ".poem" ).click(function() {
  $(".all_contents").css({"display": "none"}),
  $(".novel_menu").css({"display": "none"}),
  $(".story_menu").css({"display": "none"}),
  $(".poem_menu").css({"display": "block"}),
   $(".jokes_menu").css({"display": "none"}),
   $(".puzzle_menu").css({"display": "none"}),
   $(".quote_menu").css({"display": "none"}),
  $(".rhythm_menu").css({"display": "none"})
  
});

$( ".jokes" ).click(function() {
  $(".all_contents").css({"display": "none"}),
  $(".poem_menu").css({"display": "none"}),
  $(".novel_menu").css({"display": "none"}),
  $(".story_menu").css({"display": "none"}),
  $(".jokes_menu").css({"display": "block"}),
  $(".puzzle_menu").css({"display": "none"}),
  $(".quote_menu").css({"display": "none"}),
  $(".rhythm_menu").css({"display": "none"})
});

$( ".puzzle" ).click(function() {
  $(".all_contents").css({"display": "none"}),
  $(".novel_menu").css({"display": "none"}),
  $(".poem_menu").css({"display": "none"}),
  $(".story_menu").css({"display": "none"}),
  $(".jokes_menu").css({"display": "none"}),
  $(".puzzle_menu").css({"display": "block"}),
  $(".quote_menu").css({"display": "none"}),
  $(".rhythm_menu").css({"display": "none"})
});
 
$( ".rhythm" ).click(function() {
  $(".all_contents").css({"display": "none"}),
  $(".poem_menu").css({"display": "none"}),
  $(".novel_menu").css({"display": "none"}),
  $(".story_menu").css({"display": "none"}),
  $(".jokes_menu").css({"display": "none"}),
  $(".puzzle_menu").css({"display": "none"}),
  $(".rhythm_menu").css({"display": "block"}),
  $(".quote_menu").css({"display": "none"})
  
});
 
 $( ".quote" ).click(function() {
  $(".all_contents").css({"display": "none"}),
  $(".novel_menu").css({"display": "none"}),
  $(".poem_menu").css({"display": "none"}),
  $(".story_menu").css({"display": "none"}),
  $(".jokes_menu").css({"display": "none"}),
  $(".puzzle_menu").css({"display": "none"}),
  $(".rhythm_menu").css({"display": "none"}),
  $(".quote_menu").css({"display": "block"})
  
});
$( ".home_menu_nav" ).click(function() {
 
  $(".novel_menu").css({"display": "block"}),
  $(".poem_menu").css({"display": "block"}),
  $(".story_menu").css({"display": "block"}),
  $(".jokes_menu").css({"display": "block"}),
  $(".puzzle_menu").css({"display": "block"}),
  $(".rhythm_menu").css({"display": "block"}),
  $(".quote_menu").css({"display": "block"})
  
});
 
});


</script>
<script src="javascript/home design.js" type="text/javascript"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>