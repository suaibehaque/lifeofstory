<div class="contens_main_menu col-md-4" style="height:1000px;">
<div class="contens_title"><h2>Contents</h2></div>


<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- menu ad -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8559304347963965"
     data-ad-slot="9921070941"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>



<div class="deffult_menu novel_menu" id="contents_of_novel">

<ul>			
	
	<li><a style="color:red;" href="http://www.life-of-story.com/upponnas/akjonmayaboti/akjonmayaboti.php">একজন মায়াবতী- হুমায়ূন আহমেদ (পৃষ্ঠা-৯)</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">একজন মায়াবতী- হুমায়ূন আহমেদ (পৃষ্ঠা-১০)</a></li>


</ul>

</div>


<div class="deffult_menu poem_menu" id="contents_of_poem" style="display:block;">

<ul>			
    <li><a href="http://www.life-of-story.com/poem/jonmovumi bangla/poem_jonmovumi bangla.php">জন্মভূমি বাংলা </a></li>
    <li><a href="http://www.life-of-story.com/poem/ahoban/poem_ahoban.php">আহ্বান </a></li>
    <li><a href="http://www.life-of-story.com/poem/mukt pakhi/poem_mukt pakhi.php">মুক্ত পাখি</a></li>
    <li><a href="http://www.life-of-story.com/poem/vabona/poem_vabona.php">ভাবনা</a></li>
	<li><a href="http://www.life-of-story.com/poem/sotter joy/poem_sotter joy.php">সত্যের জয়</a></li>
    <li><a href="http://www.life-of-story.com/poem/sopno/poem_sopno.php">স্বপ্ন</a></li>
    <li><a href="http://www.life-of-story.com/poem/ekti fuler golpo/ekti fuler golpo.php">একটি ফুলের গল্প</a></li>
	<li><a href="http://www.life-of-story.com/poem/shikhok/poem_shikhok.php">শিক্ষক</a></li>
	<li><a href="http://www.life-of-story.com/poem/VALOBASAR PASSWORD/poem_VALOBASAR PASSWORD.php">VALOBASAR PASSWORD</a></li>
	<li><a href="http://www.life-of-story.com/poem/opekha/poem_opekha.php">অপেক্ষা</a></li>
	<li><a href="http://www.life-of-story.com/poem/parbe ki uttor dite/poem_parbe ki uttor dite.php">পারবে কি উত্তর দিতে </a></li>
	<li><a href="http://www.life-of-story.com/poem/Morning Of Love/poem_Morning Of Love.php">Morning Of Love</a></li>
	


</ul>

</div>


<div class="deffult_menu story_menu" id="contents_of_story" style="display:block;">

<ul>			
	
<li><a  href="http://www.life-of-story.com/story/fele asa srity/story_fele asa srity.php">ফেলে আসা স্মৃতি</a></li>	
<li><a  href="http://www.life-of-story.com/story/Accident/story_Accident.php">এ্যাক্সিডেন্ট ( পার্ট-১ )</a></li>	
	<li><a  href="http://www.life-of-story.com/story/Accident/story_Accident-2.php">এ্যাক্সিডেন্ট ( পার্ট-২ )</a></li>
	<li><a  href="http://www.life-of-story.com/story/Accident/story_Accident-3.php">এ্যাক্সিডেন্ট ( পার্ট-৩ )</a></li>
	<li><a  href="http://www.life-of-story.com/story/Accident/story_Accident-4.php">এ্যাক্সিডেন্ট ( পার্ট-৪)</a></li>
	<li><a  href="http://www.life-of-story.com/story/Accident/story_Accident-5.php">এ্যাক্সিডেন্ট ( পার্ট-৫)</a></li>
	<li><a  href="http://www.life-of-story.com/story/acharon/story_acharon.php">আচরণ</a></li>

</ul>

</div>



<div class="deffult_menu jokes_menu" id="contents_of_jokes">

<ul>			
	
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/jokes/pasmisali jokes/pasmisali jokes-4.php">পাঁচমিশালী জোকস-৪</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/jokes/pasmisali jokes/pasmisali jokes-3.php">পাঁচমিশালী জোকস-৩</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/jokes/pasmisali jokes/pasmisali jokes-2.php">পাঁচমিশালী জোকস-২</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/jokes/pasmisali jokes/pasmisali jokes-1.php">পাঁচমিশালী জোকস-১</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/jokes/boltur jokes/boltur jokes 1.php">বল্টু জোকস-১</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/jokes/boltur jokes/boltur jokes 2 .php">বল্টু জোকস-২</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">বল্টু জোকস-৩</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">বল্টু জোকস-৪</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">বল্টু জোকস-৫</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">ছাত্র-শিক্ষক জোকস	</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">স্বামী-স্ত্রী জোকস</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">প্রেমিক-প্রেমিকা জোকস</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">নাসিরুদ্দিন হোজ্জা জোকস</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">গোপাল ভার জোকস</a></div></li>
	<li><div class="hide_jokes_menu"><a  href="http://www.life-of-story.com/comming soon/comming soon.php">ডাক্তার-রোগী জোকস</a></div></li><li><div class="hide_jokes_menu"><a  href="comming soon/comming soon.php">মদ ও মাতাল জোকস</a></div></li>
	
	
</ul>
</div>

<div class="deffult_menu puzzle_menu" id="contents_of_puzzle">

<ul>			
	<li><a href="http://www.life-of-story.com/puzzle/1st part puzzle/1st part puzzle.php">প্রথম পর্বের ধাঁধা</a></li>
	<li><a href="http://www.life-of-story.com/puzzle/2nd part puzzle/2nd part puzzle.php">দ্বিতীয় পর্বের ধাঁধা</a></li>
	<li><a href="http://www.life-of-story.com/puzzle/3rd part puzzle/3rd part puzzle.php">তৃতীয়	পর্বের ধাঁধা</a></li>
	<li><a href="http://www.life-of-story.com/puzzle/4th part puzzle/4th part puzzle.php">চতুর্থ পর্বের ধাঁধা</a></li>
	<li><a href="http://www.life-of-story.com/puzzle/5th part puzzle/5th part puzzle.php">পঞ্চম পর্বের ধাঁধা</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">ষষ্ঠ পর্বের ধাঁধা</a></li>
	<li><a  href="http://www.life-of-story.com/comming soon/comming soon.php">সপ্তম পর্বের ধাঁধা</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">অষ্টম পর্বের ধাঁধা</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">নবম পর্বের ধাঁধা</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">দশম পর্বের ধাঁধা</a></li>
	
</ul>
</div>

<div class="deffult_menu rhythm_menu" id="contents_of_rhythm">

<ul>			
	<li><a href="http://www.life-of-story.com/rhythm/1st part rhythm/1st part rhythm.php">প্রথম পর্বের ছন্দ</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">দ্বিতীয় পর্বের ছন্দ</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">তৃতীয়	পর্বের ছন্দ</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">চতুর্থ পর্বের ছন্দ</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">পঞ্চম পর্বের ছন্দ</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">ষষ্ঠ পর্বের ছন্দ</a></li>
	<li><a  href="http://www.life-of-story.com/comming soon/comming soon.php">সপ্তম পর্বের ছন্দ</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">অষ্টম পর্বের ছন্দ</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">নবম পর্বের ছন্দ</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">দশম পর্বের ছন্দ</a></li>
	
</ul>
</div>

<div class="deffult_menu quote_menu" id="contents_of_quote">

<ul>			
	<li><a href="http://www.life-of-story.com/quote/1st part quote/1st part quote.php">প্রথম পর্বের উক্তি</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">দ্বিতীয় পর্বের উক্তি</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">তৃতীয়	পর্বের উক্তি</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">চতুর্থ পর্বের উক্তি</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">পঞ্চম পর্বের উক্তি</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">ষষ্ঠ পর্বের উক্তি</a></li>
	<li><a  href="http://www.life-of-story.com/comming soon/comming soon.php">সপ্তম পর্বের উক্তি</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">অষ্টম পর্বের উক্তি</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">নবম পর্বের উক্তি</a></li>
	<li><a href="http://www.life-of-story.com/comming soon/comming soon.php">দশম পর্বের উক্তি</a></li>
	
</ul>
</div>


</div>

