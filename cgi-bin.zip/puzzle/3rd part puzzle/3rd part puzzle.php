<?php

require_once("../../header.php");

?>

<div class="container-fluid">
<div class="row full_color">


<div class="col-md-8 acharon">

<h3>তৃতীয় পর্বের ধাঁধা</h3>
<ol>
<li>
 এক চাকার এমন চক্কর <br/>ভাঙলে ফুঁড়ে ছপ্পরা।<br/>উত্তর: টাকা
</li>
<li>
বর্ষাকালে তিন অক্ষরে <br/> আয়েশ করে খায়<br/> কাটলে মাথা সুন্দরীদের<br/> হাতে উঠে যায়।<br/>উত্তরঃ খিচুড়ি।
</li>
<li>

 চলতে চলতে খসলো শির <br/>
মাথা কাটলে চললো ফির।<br/>উত্তর: পেন্সিল 

</li>
<li>

ঘর সে এমন নেই দুয়ার<br/>
মাটি চাপা ছাদের পর<br/>
নিঃশব্দে মানুষ বাস<br/>
যায়না আলো, নেই বাতাস।<br/>উত্তর: কবর

</li>

<li>

জলে থাকে তবু মাছ নয় <br/>
মাছ বলে বাজারে বিক্রি হয়।<br/>উত্তর: চিংড়িমাছ
</li>

</ol>

</div>






<?php

require_once("../../side content.php");

?>


</div>
</div>


<?php 

require_once("../../footer.php");

?>
