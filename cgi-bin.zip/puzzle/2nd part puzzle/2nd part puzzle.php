<?php

require_once("../../header.php");

?>

<div class="container-fluid">
<div class="row full_color">


<div class="col-md-8 acharon">

<h3>দ্বিতীয় পর্বের ধাঁধা</h3>
<ol>
<li>
গাছ নেই,শুধু পাতা, <br/>মুখ নেই, কত কথা...<br/>উত্তর: বই
</li>
<li>
হাত নেই পা নেই <br/> তবু সে চলে<br/> অনাহারে মরে মানুষ<br/>এর অভাব হলে...<br/>উত্তর: টাকা
</li>
<li>

শীত কালে যার নেইকো মান <br/>
গ্রীষ্ম কালে পায় সু-সম্মান।<br/>উত্তর: পাখা 

</li>
<li>

সাজালে সাজে বাজালে বাজে<br/>
রান্নায়ও সে কাজের।<br/>
 বলো কি সে?<br/>উত্তর: মাটির হাঁড়ি 

</li>

<li>

বারো মাসের কচি মেয়ে<br/>
তেরো মাসে পড়ে<br/>
ভাইনে বাঁয়ে গণ্ডা গণ্ডা<br/>
ছেলে প্রসব করে।<br/>উত্তর: কলা গাছ</span>

</li>

</ol>

</div>






<?php

require_once("../../side content.php");

?>


</div>
</div>


<?php 

require_once("../../footer.php");

?>