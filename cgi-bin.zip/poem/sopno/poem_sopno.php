<?php

require_once("../../header.php");

?>

<div class="container-fluid">
<div class="row full_color">





<div class="col-md-8 writing_content">


<div class="m_o_l">স্বপ্ন</div>
<h3>স্বপ্ন দেখি এলোমেলো ;</h3>
<h3>স্বপ্নগুলো ভাঙা।</h3>
<h3>স্বপ্ন দেখি সাদা কালো;</h3>
<h3>স্বপ্ন দেখি রাঙা।</h3></br>

<h3>স্বপ্ন দেখি ধনী হওয়ার;</h3>
<h3>স্বপ্ন দেখি ভূমি।</h3>
<h3>স্বপ্ন দেখি বনজঙ্গল;</h3>
<h3>স্বপ্ন মরুভূমি।</h3></br>

<h3>স্বপ্নগুলো কাঁদায় শুধু;</h3>
<h3>স্বপ্নগুলো হাসায়।</h3>
<h3>স্বপ্ন তোমায় কাছে ডাকে;</h3>
<h3>স্বপ্ন ভালোবাসায়।<span style="font-size:15px;">[ সাদিয়া ইসলাম ] </span></h3>


</div>

 





<?php

require_once("../../side content.php");

?>


</div>
</div>


<?php 

require_once("../../footer.php");

?>