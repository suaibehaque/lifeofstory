<?php

require_once("../../header.php");

?>

<div class="container-fluid">
<div class="row full_color">


<div class="col-md-8 writing_content">


<h2><center>মুক্ত পাখি</center></h2>
<h3>মিস বলেছেন পড়তে হবে</h3>
<h3>আম্মু বলেন পড়ো!</h3>
<h3>আব্বু এসে বলল তখন</h3>
<h3>শরীর চর্চা করো।</h3></br>

<h3>মামা এসে বলল হঠাৎ</h3>
<h3>করছ কি সব যা তা!</h3>
<h3>আর্ট শেখার দাও এনে সব</h3>
<h3>কালার, ড্রয়িং খাতা।</h3>
<h3>বড় আপু বলল এসে</h3>
<h3>দেখবে টিভি চলো</h3>
<h3>জি বাংলার এই অ্যাপিসোড</h3>
<h3>মজার হবে বলো।</h3></br>

<h3>আমি বলি মুক্ত পাখি</h3>
<h3>হয়ে সারাক্ষণ</h3>
<h3>স্বদেশ-বিদেশ ঘুরে</h3>
<h3>জয় করব সবার মন।<span style="font-size:15px;">[সাদিয়া ইসলাম অর্পিতা] </span></h3>


</div>
 





<?php

require_once("../../side content.php");

?>


</div>
</div>


<?php 

require_once("../../footer.php");

?>