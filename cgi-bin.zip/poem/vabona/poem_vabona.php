<?php

require_once("../../header.php");

?>

<div class="container-fluid">
<div class="row full_color">





<div class="col-md-8 writing_content">


<h2><center>ভাবনা</center></h2>
<h3>নাও দেখি পেন্সিল, লেখ দেখি উত্তর</h3>
<h3>ভেজালটা কী জিনিস?</h3>
<h3>লেখ দেখি সত্ত্বর।</h3>
<h3>ঘুষ কেন খায় লোকে, ঘাস কেন খায় না?</h3>
<h3>মুখ কেন দেখে লোকে, কাছে নিয়ে আয়না?</h3>
<h3>দাঁত কেন মাজে আর চুল কেন আঁচড়ায়?</h3>
<h3>পানি যদি পান করে, ভাত তবে কেন খায়?</h3>
<h3>এইসব উত্তর ঠিক যদি দিতে চাও,</h3>
<h3>পেটপুরে আজ তবে জ্ঞানটুকু খেয়ে নাও।<span style="font-size:15px;">[সাদিয়া ইসলাম অর্পিতা] </span></h3>


</div>


 





<?php

require_once("../../side content.php");

?>


</div>
</div>


<?php 

require_once("../../footer.php");

?>