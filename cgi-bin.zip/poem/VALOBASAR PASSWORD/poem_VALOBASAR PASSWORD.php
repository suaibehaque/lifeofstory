<?php

require_once("../../header.php");

?>

<div class="container-fluid">
<div class="row full_color">





<div class="col-md-8 writing_content">

<h2> <center>VALOBASAR PASSWORD </center>   </h2>

<h3>আমি খুবি SORRY,</h3> 
<h3>তোমায় খুব ভালোবাসার  জন্য । </h3> 
<h3>আমি খুবি SORRY, </h3> 
<h3>সব সময় তোমার কথা ভাবার জন্য । </h3>
<h3>আমি খুবি  SORRY, </h3>
<h3>তোমার মিথ্যে ভালোবাসাটাকে  সত্যি ভাবার জন্য । </h3>
<h3>আমি খুবি SORRY, </h3>
<h3>তোমাকে নিয়ে হাজারো সুখের স্বপ্ন দেখার জন্য । </h3>
<h3>আমি খুবি SORRY, </h3>
<h3>তোমাকে ঠিক মনের ভেতর থেকেই  CARE করার জন্য । </h3>
<h3>আমি খুবি SORRY, </h3>
<h3>তোমাকে আমার জীবন ভাবার জন্য ।   </h3>
<h3>আমি সত্যি খুবি SORRY, </h3>
<h3>তুমি আর ফিরে আসবেনা জেনেও তোমাকে ,  </h3>
<h3>সেই আগের মতো করেই ভালোবাসার জন্য ।</h3>
<h3>I AM SORRY </h3>
<h3>I AM REALLY SORRY</h3>
<h3>এখনো ভালোবেসে যাই তোমায় । </h3>
<h3>তাই আমিই  SORRY</h3>

</div>


 





<?php

require_once("../../side content.php");

?>


</div>
</div>


<?php 

require_once("../../footer.php");

?>