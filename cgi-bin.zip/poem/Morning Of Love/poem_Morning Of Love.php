<?php

require_once("../../header.php");

?>

<div class="container-fluid">
<div class="row full_color">


<div class="col-md-8 writing_content">


<div class="m_o_l">Morning Of Love</div>
<h3>আমার সকালটা যেন    </h3>
<h3> তোমায়  ঘিরে ।     </h3>
<h3>আমার ভালো লাগা   </h3>
<h3> তোমার মাঝে ।       </h3>
<h3>পথ হারা পাখির মতো      </h3>
<h3>  তোমায় খোঁজে মন ।    </h3>
<h3>আমার অন্ধকার হৃদয়ে    </h3>
<h3>  তুমি আমার আলো ।      </h3>
<h3>আমার হাজার দুখের মাঝে      </h3>
<h3>  তুমি আমার সুখ ।      </h3>
<h3>গতি বিহীন পাখির মত  </h3>
<h3> তোমায় খোঁজে মন ।      </h3>
<h3>আমার মাঝ রাতের আঁধার তুমি     </h3>
<h3>আমার ভালো লাগা গান তুমি ।     </h3>
<h3>আমার জীবনের ছন্দ তুমি     </h3>
<h3>আমার জছনার আলো তুমি ।    </h3>
<h3>আমার জীবন সাথী তুমি     </h3>
<h3>তুমিই আমার জীবন ।     </h3>


</div>
 





<?php

require_once("../../side content.php");

?>


</div>
</div>


<?php 

require_once("../../footer.php");

?>