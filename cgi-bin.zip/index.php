<?php

require_once("header.php");

?>

<div class="container-fluid">
<div class="row full_color">





<div class="col-md-8">

<div class="row full_color">


<div class="col-md-6">
<div class="home_content novel">

<a class="" href="#contents_of_novel">  Novel/উপন্যাস  </a>

</div>
</div>


<div class="col-md-6">
<div class="home_content story">

<a class="" href="#contents_of_story">STORY/গল্প</a>

</div>
</div>

<div class="col-md-6">
<div class="home_content poem">


<a class="" href="#contents_of_poem">POEM/কবিতা</a>

</div>
</div>

<div class="col-md-6">
<div class="home_content jokes">


<a class="" href="#contents_of_jokes">JOKES/কৌতুক</a>

</div>
</div>

<div class="col-md-6">
<div class="home_content puzzle">


<a class="" href="#contents_of_puzzle">PUZZLE/ধাঁধা</a>

</div>
</div>

<div class="col-md-6">
<div class="home_content rhythm">


<a class="" href="#contents_of_rhythm">RHYTHM/ছন্দ</a>

</div>
</div>
<div class="col-md-6">
<div class="home_content quote">


<a class="" href="#contents_of_quote"> Quote/উক্তি </a>

</div>
</div>

</div>
</div>




<?php

require_once("side content.php");

?>


</div>
</div>


<?php 

require_once("footer.php");

?>